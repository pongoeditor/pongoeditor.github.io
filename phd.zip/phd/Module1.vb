﻿Imports System
Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading

Module Module1

    <DllImport("kernel32.dll")> _
    Private Function GetConsoleWindow() As IntPtr
    End Function

    <DllImport("user32.dll")> _
    Private Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, _
                                  ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function

    Private Const WM_SETICON As UInteger = &H80
    Private Const ICON_SMALL As Integer = 0
    Private Const ICON_BIG As Integer = 1

    Private Const INNER_W As Integer = 58

    Private Const GITHUB_TOKEN As String = "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"
    Private Const GITHUB_REPO As String = "pongoeditor/pongoeditor.github.io"
    Private Const GITHUB_BRANCH As String = "main"
    Private Const GITHUB_FOLDER As String = "submit"
    Private Const PUBLIC_BASE As String = "https://pongo.my.id/submit"
    Private Const COMMIT_MESSAGE As String = "New PHD report submission"

    Private _smartctlPath As String = Nothing
    Private _curlPath As String = Nothing
    Private _curlCaPath As String = Nothing
    Private _hiddenDir As String = Nothing
    Private _devices As New List(Of String)()
    Private _deviceArgs As New List(Of String)()
    Private _deviceDesc As New List(Of String)()
    Private _deviceModel As New List(Of String)()
    Private _deviceType As New List(Of String)()
    Private _cachedData As String = Nothing
    Private _cachedDev As String = Nothing

    Private Sub ApplyConsoleIcon()
        Try
            Dim hWnd As IntPtr = GetConsoleWindow()
            If hWnd = IntPtr.Zero Then Return

            Dim ico As System.Drawing.Icon = Nothing
            Try
                ico = CType(My.Resources.ResourceManager.GetObject("favicon"), System.Drawing.Icon)
            Catch
            End Try

            If ico Is Nothing Then Return

            SendMessage(hWnd, WM_SETICON, New IntPtr(ICON_SMALL), ico.Handle)
            SendMessage(hWnd, WM_SETICON, New IntPtr(ICON_BIG), ico.Handle)
        Catch
        End Try
    End Sub

    Sub Main(ByVal args As String())
        AddHandler Console.CancelKeyPress, AddressOf OnCancel
        PrintHeader()
        ApplyConsoleIcon()

        Try
            ExtractHidden()
            Console.WriteLine()

            If args IsNot Nothing AndAlso args.Length > 0 Then
                Dim cmd As String = args(0).ToLower()
                If cmd = "info" OrElse cmd = "status" OrElse cmd = "detail" OrElse cmd = "all" OrElse cmd = "temp" OrElse cmd = "probe" OrElse cmd = "export" OrElse cmd = "upload" Then
                    DoScanSilent()
                End If
                RunCommand(String.Join(" ", args))
                Console.WriteLine()
                Console.WriteLine("  Press any key to exit...")
                Console.ReadKey(True)
            Else
                Console.ForegroundColor = ConsoleColor.DarkGray
                Console.WriteLine("  Type 'help' or '?' to see available commands.")
                Console.ResetColor()
                InteractiveLoop()
            End If
        Catch ex As Exception
            PrintError("Program halted unexpectedly.")
        Finally
            CleanupAll()
        End Try
    End Sub

    Private Sub ExtractHidden()
        Console.ForegroundColor = ConsoleColor.DarkGray
        Console.WriteLine("  Starting PHD ...")
        Console.ResetColor()

        Dim basePath As String = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
        basePath = Path.Combine(basePath, "Microsoft")
        basePath = Path.Combine(basePath, "Windows")
        basePath = Path.Combine(basePath, "INetCache")

        If Not Directory.Exists(basePath) Then
            basePath = Path.GetTempPath()
        End If

        Dim rand As New Random()
        Dim folderName As String = "." & Guid.NewGuid().ToString("N").Substring(0, 12) & _
                                    rand.Next(1000, 9999).ToString()

        _hiddenDir = Path.Combine(basePath, folderName)
        Directory.CreateDirectory(_hiddenDir)

        Try
            Dim di As New DirectoryInfo(_hiddenDir)
            di.Attributes = FileAttributes.Hidden Or FileAttributes.System
        Catch
        End Try

        Dim asm As Assembly = Assembly.GetExecutingAssembly()

        Try
            _smartctlPath = ExtractOne(asm, "smartctl.exe", _hiddenDir)
        Catch
            _smartctlPath = Nothing
        End Try

        Try
            _curlPath = ExtractOne(asm, "curl.exe", _hiddenDir)
        Catch
            _curlPath = Nothing
        End Try

        Try
            _curlCaPath = ExtractOne(asm, "curl-ca-bundle.crt", _hiddenDir)
        Catch
            _curlCaPath = Nothing
        End Try
    End Sub

    Private Function ExtractOne(ByVal asm As Assembly, ByVal suffix As String, ByVal dir As String) As String
        Dim actualName As String = Nothing
        Dim names() As String = asm.GetManifestResourceNames()
        For i As Integer = 0 To names.Length - 1
            If names(i).ToLower().EndsWith(suffix.ToLower()) Then
                actualName = names(i)
                Exit For
            End If
        Next

        If actualName Is Nothing Then
            Throw New Exception("missing")
        End If

        Dim ext As String = Path.GetExtension(suffix)
        Dim prefix As String = "winsta"
        If suffix.ToLower() = "curl.exe" Then
            prefix = "curl"
        ElseIf suffix.ToLower() = "curl-ca-bundle.crt" Then
            prefix = "ca"
        End If

        Dim fileName As String = prefix & Guid.NewGuid().ToString("N").Substring(0, 8) & ext
        Dim target As String = Path.Combine(dir, fileName)

        Dim s As Stream = asm.GetManifestResourceStream(actualName)
        Dim fs As New FileStream(target, FileMode.Create, FileAccess.Write)
        Try
            Dim buf(8191) As Byte
            Dim n As Integer = s.Read(buf, 0, buf.Length)
            While n > 0
                fs.Write(buf, 0, n)
                n = s.Read(buf, 0, buf.Length)
            End While
        Finally
            fs.Close()
            s.Close()
        End Try

        Try
            Dim fi As New FileInfo(target)
            fi.Attributes = FileAttributes.Hidden Or FileAttributes.System
        Catch
        End Try

        Return target
    End Function

    Private Sub CleanupAll()
        If _smartctlPath IsNot Nothing Then TryDeleteFile(_smartctlPath)
        If _curlPath IsNot Nothing Then TryDeleteFile(_curlPath)
        If _curlCaPath IsNot Nothing Then TryDeleteFile(_curlCaPath)

        If _hiddenDir IsNot Nothing Then
            For i As Integer = 1 To 6
                Try
                    If Directory.Exists(_hiddenDir) Then
                        Directory.Delete(_hiddenDir, True)
                    End If
                    Exit For
                Catch
                    Thread.Sleep(120)
                End Try
            Next
        End If
    End Sub

    Private Sub TryDeleteFile(ByVal path As String)
        For i As Integer = 1 To 6
            Try
                If File.Exists(path) Then
                    File.SetAttributes(path, FileAttributes.Normal)
                    File.Delete(path)
                End If
                Exit For
            Catch
                Thread.Sleep(120)
            End Try
        Next
    End Sub

    Private Sub OnCancel(ByVal sender As Object, ByVal e As ConsoleCancelEventArgs)
        e.Cancel = True
        Console.WriteLine()
        Console.ForegroundColor = ConsoleColor.DarkYellow
        Console.WriteLine("  Cancelled. Cleaning up...")
        Console.ResetColor()
        CleanupAll()
        Environment.Exit(0)
    End Sub

    Private Sub InteractiveLoop()
        While True
            Console.WriteLine()
            Console.ForegroundColor = ConsoleColor.Gray
            Console.Write("  ")
            Console.ForegroundColor = ConsoleColor.White
            Console.Write("phd")
            Console.ForegroundColor = ConsoleColor.DarkGray
            Console.Write(" > ")
            Console.ResetColor()

            Dim line As String = Console.ReadLine()
            If line Is Nothing Then Exit While

            line = line.Trim()
            If line.Length = 0 Then Continue While

            Dim low As String = line.ToLower()
            If low = "exit" OrElse low = "quit" OrElse low = "q" Then Exit While

            RunCommand(line)
        End While
    End Sub

    Private Sub RunCommand(ByVal cmdLine As String)
        Dim parts() As String = cmdLine.Split(New Char() {" "c}, StringSplitOptions.RemoveEmptyEntries)
        If parts.Length = 0 Then Return

        Select Case parts(0).ToLower()
            Case "help", "?"
                PrintHelp()
            Case "scan", "list"
                DoScan()
            Case "info"
                DoShowInfo(GetArg(parts, 1))
            Case "status", "health"
                DoShowStatus(GetArg(parts, 1))
            Case "temp", "temperature"
                DoShowTemperature(GetArg(parts, 1))
            Case "detail", "attr"
                DoShowDetail(GetArg(parts, 1))
            Case "all"
                DoShowAll(GetArg(parts, 1))
            Case "probe"
                DoProbe(GetArg(parts, 1), GetArg(parts, 2))
            Case "export"
                DoExport(GetArg(parts, 1), GetArg(parts, 2), GetArg(parts, 3))
            Case "upload", "submit", "share"
                DoUpload(GetArg(parts, 1))
            Case "about", "credit", "credits"
                PrintAbout()
            Case "clear", "cls"
                PrintHeader()
                ApplyConsoleIcon()
            Case Else
                Console.ForegroundColor = ConsoleColor.DarkYellow
                Console.WriteLine("  Unknown command: " & parts(0))
                Console.ResetColor()
                Console.ForegroundColor = ConsoleColor.DarkGray
                Console.WriteLine("  Type 'help' to see available commands.")
                Console.ResetColor()
        End Select
    End Sub

    Private Function GetArg(ByVal parts() As String, ByVal idx As Integer) As String
        If parts.Length > idx Then Return parts(idx)
        Return Nothing
    End Function

    Private Sub DoUpload(ByVal arg As String)
        Dim dev As String
        Try
            dev = ResolveDevice(arg)
        Catch ex As Exception
            PrintError(ex.Message) : Return
        End Try

        If _curlPath Is Nothing Then
            Console.WriteLine()
            SectionTop("UPLOAD REPORT", ConsoleColor.DarkRed)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("   [ XX ]  Upload module is unavailable.", ConsoleColor.DarkRed)
            SectionLine("           Please reinstall PHD to restore it.", ConsoleColor.DarkGray)
            SectionLine("", ConsoleColor.Gray)
            SectionBottom(ConsoleColor.DarkRed)
            Return
        End If

        If GITHUB_TOKEN Is Nothing OrElse GITHUB_TOKEN.Length < 20 OrElse GITHUB_TOKEN.StartsWith("ghp_xxx") Then
            Console.WriteLine()
            SectionTop("UPLOAD REPORT", ConsoleColor.DarkRed)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("   [ XX ]  Upload service is not configured.", ConsoleColor.DarkRed)
            SectionLine("           Please contact the PHD maintainer.", ConsoleColor.DarkGray)
            SectionLine("", ConsoleColor.Gray)
            SectionBottom(ConsoleColor.DarkRed)
            Return
        End If

        Dim model As String = GetDeviceModel(dev)
        Dim dtype As String = GetDeviceType(dev)

        Console.WriteLine()
        SectionTop("UPLOAD REPORT", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   Device          :  " & model, ConsoleColor.Gray)
        SectionLine("   Report type     :  Hardware diagnostic report", ConsoleColor.Gray)
        SectionLine("   Destination     :  pongo.my.id", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   Preparing report...", ConsoleColor.DarkGray)

        Dim raw As String = GetFullData(dev)
        Dim infoRows As List(Of String()) = BuildInfoRows(raw)
        Dim smartRows As List(Of String()) = BuildSmartRows(raw)
        Dim health As String = BuildHealthText(raw)
        Dim tempText As String = BuildTempText(raw)
        Dim errText As String = BuildErrorText(raw)
        Dim selfTestText As String = BuildSelfTestText(raw)

        Dim html As String = ExportHtmlBody(model, dtype, infoRows, health, tempText, smartRows, errText, selfTestText)

        Dim ts As String = DateTime.Now.ToString("yyyyMMdd_HHmmss")
        Dim rand As String = Guid.NewGuid().ToString("N").Substring(0, 6)
        Dim fileName As String = ts & "_" & rand & ".html"
        Dim repoPath As String = GITHUB_FOLDER & "/" & fileName

        SectionLine("   Submitting report...", ConsoleColor.DarkGray)

        Dim b64 As String = Convert.ToBase64String(Encoding.UTF8.GetBytes(html))

        Dim payload As New StringBuilder()
        payload.Append("{")
        payload.Append("""message"":""" & JsonEscape(COMMIT_MESSAGE) & """,")
        payload.Append("""content"":""" & b64 & """,")
        payload.Append("""branch"":""" & JsonEscape(GITHUB_BRANCH) & """")
        payload.Append("}")

        Dim payloadPath As String = Path.Combine(_hiddenDir, "p_" & Guid.NewGuid().ToString("N").Substring(0, 8) & ".json")
        File.WriteAllText(payloadPath, payload.ToString(), New UTF8Encoding(False))

        Dim url As String = "https://api.github.com/repos/" & GITHUB_REPO & "/contents/" & repoPath
        Dim args As String = "-s -S --max-time 90 -X PUT " & _
                             "-H ""Authorization: Bearer " & GITHUB_TOKEN & """ " & _
                             "-H ""Accept: application/vnd.github+json"" " & _
                             "-H ""Content-Type: application/json"" " & _
                             "-H ""User-Agent: PHD/1.0"" " & _
                             "-H ""X-GitHub-Api-Version: 2022-11-28"" " & _
                             "--data-binary ""@" & payloadPath & """ " & _
                             "-w ""\n<<<HTTP>>>%{http_code}"" " & _
                             """" & url & """"

        Dim resp As String = InvokeCurl(args)

        TryDeleteFile(payloadPath)

        Dim httpCode As Integer = 0
        Dim marker As String = "<<<HTTP>>>"
        Dim mIdx As Integer = resp.LastIndexOf(marker)
        Dim body As String = resp
        If mIdx >= 0 Then
            body = resp.Substring(0, mIdx)
            Dim codeStr As String = resp.Substring(mIdx + marker.Length).Trim()
            Integer.TryParse(codeStr, httpCode)
        End If

        SectionLine("", ConsoleColor.Gray)

        Dim success As Boolean = (httpCode = 200 OrElse httpCode = 201) AndAlso body.IndexOf("""content"":") >= 0

        If success Then
            Dim publicUrl As String = PUBLIC_BASE
            If Not publicUrl.EndsWith("/") Then publicUrl &= "/"
            publicUrl &= fileName

            SectionLine("   [ OK ]  Report submitted successfully", ConsoleColor.Gray)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("   Your report is now available at:", ConsoleColor.Gray)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("       " & publicUrl, ConsoleColor.White)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("   Please allow up to one minute for the report", ConsoleColor.DarkGray)
            SectionLine("   to become accessible. Refresh the page if it", ConsoleColor.DarkGray)
            SectionLine("   does not load right away.", ConsoleColor.DarkGray)
        Else
            Dim title As String = "Report could not be submitted"
            Dim reason As String = "The destination server reported an unknown error."
            Dim hint As String = "Please try again in a few moments."

            If httpCode = 401 Then
                title = "Report could not be submitted"
                reason = "The upload service was rejected by the destination server."
                hint = "Please contact the PHD maintainer to update the service credentials."
            ElseIf httpCode = 403 Then
                title = "Report could not be submitted"
                reason = "The upload service is not authorized to publish reports."
                hint = "Please contact the PHD maintainer to restore upload access."
            ElseIf httpCode = 404 Then
                title = "Report could not be submitted"
                reason = "The destination location could not be found."
                hint = "Please contact the PHD maintainer."
            ElseIf httpCode = 409 Then
                title = "Report could not be submitted"
                reason = "A conflicting submission already exists."
                hint = "Please try again in a few moments."
            ElseIf httpCode = 422 Then
                title = "Report could not be submitted"
                reason = "The destination server rejected the report format."
                hint = "Please try again with a different device."
            ElseIf httpCode = 0 Then
                title = "Report could not be submitted"
                reason = "PHD could not reach the destination server."
                hint = "Please check your internet connection and try again."
            End If

            SectionLine("   [ XX ]  " & title, ConsoleColor.DarkRed)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("       " & reason, ConsoleColor.DarkRed)
            SectionLine("       " & hint, ConsoleColor.DarkGray)
        End If

        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Function InvokeCurl(ByVal arguments As String) As String
        Dim psi As New ProcessStartInfo()
        psi.FileName = _curlPath
        psi.Arguments = arguments
        psi.UseShellExecute = False
        psi.RedirectStandardOutput = True
        psi.RedirectStandardError = True
        psi.CreateNoWindow = True

        If _curlCaPath IsNot Nothing Then
            Try
                psi.EnvironmentVariables("CURL_CA_BUNDLE") = _curlCaPath
                psi.EnvironmentVariables("SSL_CERT_FILE") = _curlCaPath
            Catch
            End Try
        End If

        Dim proc As Process = Process.Start(psi)
        Dim sb As New StringBuilder()
        Try
            sb.Append(proc.StandardOutput.ReadToEnd())
            Dim e As String = proc.StandardError.ReadToEnd()
            If e.Length > 0 Then
                sb.Append(vbLf)
                sb.Append(e)
            End If
            proc.WaitForExit()
        Finally
            proc.Close()
        End Try
        Return sb.ToString()
    End Function

    Private Sub DoScanSilent()
        _devices.Clear()
        _deviceArgs.Clear()
        _deviceDesc.Clear()
        _deviceModel.Clear()
        _deviceType.Clear()
        _cachedData = Nothing
        _cachedDev = Nothing

        If _smartctlPath Is Nothing Then Return

        Dim raw As String = InvokeSmartctl("--scan")
        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.Length = 0 OrElse t.StartsWith("#") Then Continue For

            Dim desc As String = ""
            Dim idx As Integer = t.IndexOf("#"c)
            If idx >= 0 Then
                desc = t.Substring(idx + 1).Trim()
                t = t.Substring(0, idx).Trim()
            End If

            If t.Length = 0 Then Continue For

            Dim sp() As String = t.Split(New Char() {" "c}, StringSplitOptions.RemoveEmptyEntries)
            If sp.Length > 0 AndAlso sp(0).StartsWith("/dev/") Then
                _devices.Add(sp(0))
                _deviceArgs.Add(t)
                If desc.Length = 0 Then desc = sp(0)
                _deviceDesc.Add(desc)
            End If
        Next

        For i As Integer = 0 To _devices.Count - 1
            Dim mdl As String = Nothing
            Dim dtype As String = "DISK"

            Dim info As String = InvokeSmartctl("--info " & _deviceArgs(i))
            mdl = FindField(info, New String() {"Device Model", "Model Number", "Product", "Model"})

            If mdl Is Nothing OrElse mdl.Length = 0 Then
                Dim tries() As String = New String() {"sat", "scsi", "nvme", "ata", "sat,12", "sat,16"}
                For Each tryD As String In tries
                    Try
                        Dim info2 As String = InvokeSmartctl("-d " & tryD & " --info " & _devices(i))
                        Dim mdl2 As String = FindField(info2, New String() {"Device Model", "Model Number", "Product", "Model"})
                        If mdl2 IsNot Nothing AndAlso mdl2.Length > 0 Then
                            mdl = mdl2
                            _deviceArgs(i) = _devices(i) & " -d " & tryD
                            info = info2
                            Exit For
                        End If
                    Catch
                    End Try
                Next
            End If

            If mdl Is Nothing OrElse mdl.Length = 0 Then
                mdl = "Generic storage device"
            End If
            _deviceModel.Add(mdl.Trim())

            Dim rot As String = FindField(info, New String() {"Rotation Rate"})
            If rot IsNot Nothing Then
                If rot.ToLower().IndexOf("solid state") >= 0 Then
                    dtype = "SSD"
                Else
                    dtype = "HDD"
                End If
            Else
                Dim nvme As String = FindField(info, New String() {"NVMe Version"})
                If nvme IsNot Nothing Then
                    dtype = "NVMe"
                Else
                    Dim devLower As String = mdl.ToLower()
                    If devLower.IndexOf("ssd") >= 0 OrElse devLower.IndexOf("nvme") >= 0 Then
                        dtype = "SSD"
                    ElseIf devLower.IndexOf("hdd") >= 0 Then
                        dtype = "HDD"
                    End If
                End If
            End If
            _deviceType.Add(dtype)
        Next
    End Sub

    Private Function GetDeviceModel(ByVal dev As String) As String
        Dim idx As Integer = _devices.IndexOf(dev)
        If idx >= 0 AndAlso idx < _deviceModel.Count Then Return _deviceModel(idx)
        Return dev
    End Function

    Private Function GetDeviceType(ByVal dev As String) As String
        Dim idx As Integer = _devices.IndexOf(dev)
        If idx >= 0 AndAlso idx < _deviceType.Count Then Return _deviceType(idx)
        Return ""
    End Function

    Private Function GetDeviceArgs(ByVal dev As String) As String
        Dim idx As Integer = _devices.IndexOf(dev)
        If idx >= 0 AndAlso idx < _deviceArgs.Count Then Return _deviceArgs(idx)
        Return dev
    End Function

    Private Function GetDeviceIndex(ByVal dev As String) As Integer
        Return _devices.IndexOf(dev)
    End Function

    Private Sub DoScan()
        Console.WriteLine()
        Console.ForegroundColor = ConsoleColor.DarkGray
        Console.WriteLine("  Scanning storage devices...")
        Console.ResetColor()
        DoScanSilent()

        If _devices.Count = 0 Then
            Console.WriteLine()
            SectionTop("DETECTED STORAGE DEVICES", ConsoleColor.Gray)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("   No storage devices were detected.", ConsoleColor.DarkYellow)
            SectionLine("   Please verify that PHD is running with", ConsoleColor.DarkGray)
            SectionLine("   administrative privileges.", ConsoleColor.DarkGray)
            SectionLine("", ConsoleColor.Gray)
            SectionBottom(ConsoleColor.Gray)
            Return
        End If

        Console.WriteLine()
        SectionTop("DETECTED STORAGE DEVICES", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)

        SectionLine("  ID    MODEL                                     TYPE", ConsoleColor.DarkGray)
        SectionLine("  " & New String("-"c, 54), ConsoleColor.DarkGray)

        For i As Integer = 0 To _devices.Count - 1
            Dim mdl As String = _deviceModel(i)
            Dim tp As String = _deviceType(i)

            Dim line As String = "  " & i.ToString().PadLeft(2) & "    " & _
                                 mdl.PadRight(44) & "  " & tp.PadLeft(4)
            SectionLine(line, ConsoleColor.Gray)
        Next

        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)

        Console.WriteLine()
        Console.ForegroundColor = ConsoleColor.DarkGray
        Console.WriteLine("  Continue with:  info <ID> | status <ID> | temp <ID> | detail <ID> | probe <ID> <action> | export <ID> <fmt> | upload <ID> | all <ID>")
        Console.ResetColor()
    End Sub

    Private Sub DoShowInfo(ByVal arg As String)
        Dim dev As String
        Try
            dev = ResolveDevice(arg)
        Catch ex As Exception
            PrintError(ex.Message) : Return
        End Try

        Dim raw As String = GetFullData(dev)

        Dim family As String = FindField(raw, New String() {"Model Family"})
        Dim brand As String = ExtractBrand(family)
        If brand Is Nothing Then brand = "Unknown"

        Dim model As String = FindField(raw, New String() {"Device Model", "Model Number", "Product", "Model"})
        If model Is Nothing Then model = "-"

        Dim serial As String = FindField(raw, New String() {"Serial Number", "Serial number"})
        Dim firmware As String = FindField(raw, New String() {"Firmware Version", "Revision"})
        Dim wwn As String = FindField(raw, New String() {"LU WWN Device Id", "Logical Unit id"})
        Dim capacity As String = FindField(raw, New String() {"User Capacity", "Total NVM Capacity", "Namespace 1 Size/Capacity"})
        Dim sector As String = FindField(raw, New String() {"Sector Size", "Sector Sizes", "Logical Sector Size"})
        Dim form As String = FindField(raw, New String() {"Form Factor"})
        Dim rotation As String = FindField(raw, New String() {"Rotation Rate"})
        Dim ata As String = FindField(raw, New String() {"ATA Version is"})
        Dim sata As String = FindField(raw, New String() {"SATA Version is"})
        Dim localTime As String = FindField(raw, New String() {"Local Time is"})
        Dim smart As String = FindField(raw, New String() {"SMART support is"})
        Dim trim As String = FindField(raw, New String() {"TRIM Command support"})
        Dim ncq As String = FindField(raw, New String() {"NCQ feature is", "NCQ (depth 0/32)"})
        Dim apm As String = FindField(raw, New String() {"APM feature is", "APM level"})
        Dim wv As String = FindField(raw, New String() {"Write-Read-Verify feature is"})

        Dim totalOnly As String = "-"
        Dim bytesOnly As String = "-"
        If capacity IsNot Nothing Then
            Dim m As Match = Regex.Match(capacity, "^\s*([\d,\.]+)\s+bytes\s+\[([^\]]+)\]")
            If m.Success Then
                bytesOnly = m.Groups(1).Value
                totalOnly = m.Groups(2).Value
            Else
                totalOnly = capacity
            End If
        End If

        Dim logicalSec As String = "-"
        Dim physicalSec As String = "-"
        If sector IsNot Nothing Then
            Dim m As Match = Regex.Match(sector, "(\d+)\s+bytes\s+logical")
            If m.Success Then logicalSec = m.Groups(1).Value & " bytes"
            Dim m2 As Match = Regex.Match(sector, "(\d+)\s+bytes\s+physical")
            If m2.Success Then physicalSec = m2.Groups(1).Value & " bytes"
            If logicalSec = "-" AndAlso physicalSec = "-" Then logicalSec = sector
        End If

        Console.WriteLine()
        SectionTop("DEVICE IDENTITY", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)

        SectionLine("   >> MODEL", ConsoleColor.White)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("        " & model, ConsoleColor.White)
        SectionLine("        Manufactured by " & brand, ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)

        Dim badges As String = "        [ " & brand & " ]"
        If form IsNot Nothing Then badges &= "  [ " & form & " ]"
        If rotation IsNot Nothing Then badges &= "  [ " & rotation & " ]"
        If totalOnly <> "-" Then badges &= "  [ " & totalOnly & " ]"
        SectionLine(badges, ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)

        SectionLine("   >> SERIAL NUMBER", ConsoleColor.White)
        SectionLine("", ConsoleColor.Gray)
        SectionLine(Dotted("Serial number", serial), ConsoleColor.Gray)
        SectionLine(Dotted("Firmware revision", firmware), ConsoleColor.Gray)
        SectionLine(Dotted("World Wide Name", wwn), ConsoleColor.Gray)
        SectionLine(Dotted("Reported on", localTime), ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)

        SectionLine("   >> STORAGE CAPACITY", ConsoleColor.White)
        SectionLine("", ConsoleColor.Gray)
        SectionLine(Dotted("Total space", totalOnly), ConsoleColor.Gray)
        SectionLine(Dotted("Raw byte count", bytesOnly), ConsoleColor.Gray)
        SectionLine(Dotted("Logical sector", logicalSec), ConsoleColor.Gray)
        SectionLine(Dotted("Physical sector", physicalSec), ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)

        SectionLine("   >> PHYSICAL FORM", ConsoleColor.White)
        SectionLine("", ConsoleColor.Gray)
        SectionLine(Dotted("Enclosure", form), ConsoleColor.Gray)
        SectionLine(Dotted("Rotational speed", rotation), ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)

        SectionLine("   >> INTERFACE PROTOCOL", ConsoleColor.White)
        SectionLine("", ConsoleColor.Gray)
        SectionLine(Dotted("ATA specification", ata), ConsoleColor.Gray)
        SectionLine(Dotted("SATA specification", sata), ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)

        SectionLine("   >> FEATURE SUPPORT", ConsoleColor.White)
        SectionLine("", ConsoleColor.Gray)
        SectionLine(Dotted("SMART", FeatureText(smart, True)), FeatureColor(smart, True))
        SectionLine(Dotted("TRIM", FeatureText(trim, False)), FeatureColor(trim, False))
        SectionLine(Dotted("NCQ", FeatureText(ncq, False)), FeatureColor(ncq, False))
        SectionLine(Dotted("APM", FeatureText(apm, False)), FeatureColor(apm, False))
        SectionLine(Dotted("Write verify", FeatureText(wv, False)), FeatureColor(wv, False))
        SectionLine("", ConsoleColor.Gray)

        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Function FeatureText(ByVal v As String, ByVal isSmart As Boolean) As String
        If v Is Nothing OrElse v.Length = 0 Then Return "Not supported"
        Dim low As String = v.ToLower()
        If low.IndexOf("not supported") >= 0 Then Return "Not supported"
        If low.IndexOf("unavailable") >= 0 Then Return "Unavailable"
        If low.IndexOf("available") >= 0 Then Return "Available"
        If low.IndexOf("disabled") >= 0 Then Return "Disabled"
        If low.IndexOf("enabled") >= 0 Then Return "Enabled"
        If low.IndexOf("unsupported") >= 0 Then Return "Unsupported"
        Return v
    End Function

    Private Function FeatureColor(ByVal v As String, ByVal isSmart As Boolean) As ConsoleColor
        If v Is Nothing OrElse v.Length = 0 Then Return ConsoleColor.DarkGray
        Dim low As String = v.ToLower()
        If low.IndexOf("available") >= 0 OrElse low.IndexOf("enabled") >= 0 Then Return ConsoleColor.Gray
        If low.IndexOf("not supported") >= 0 OrElse low.IndexOf("unavailable") >= 0 OrElse low.IndexOf("unsupported") >= 0 Then Return ConsoleColor.DarkGray
        If low.IndexOf("disabled") >= 0 Then Return ConsoleColor.DarkYellow
        Return ConsoleColor.Gray
    End Function

    Private Function Dotted(ByVal label As String, ByVal value As String) As String
        If value Is Nothing OrElse value.Length = 0 Then value = "-"
        Dim prefix As String = "        "
        Dim dots As Integer = INNER_W - prefix.Length - label.Length - 2 - value.Length
        If dots < 3 Then dots = 3
        Return prefix & label & " " & New String("."c, dots) & " " & value
    End Function

    Private Sub DoShowStatus(ByVal arg As String)
        Dim dev As String
        Try
            dev = ResolveDevice(arg)
        Catch ex As Exception
            PrintError(ex.Message) : Return
        End Try

        Dim raw As String = GetFullData(dev)
        Dim result As String = FindField(raw, New String() {"SMART overall-health self-assessment test result"})
        If result Is Nothing Then result = FindField(raw, New String() {"SMART Health Status"})

        Dim isOk As Boolean = False
        Dim isBad As Boolean = False
        Dim isUnknown As Boolean = False

        If result Is Nothing Then
            isUnknown = True
        ElseIf result.ToUpper().IndexOf("PASSED") >= 0 OrElse result.ToUpper().IndexOf("OK") >= 0 Then
            isOk = True
        ElseIf result.ToUpper().IndexOf("FAILED") >= 0 Then
            isBad = True
        Else
            isUnknown = True
        End If

        Dim hdrColor As ConsoleColor = ConsoleColor.Gray
        If isBad Then hdrColor = ConsoleColor.DarkRed
        If isUnknown Then hdrColor = ConsoleColor.DarkYellow

        Console.WriteLine()
        SectionTop("HEALTH REPORT", hdrColor)
        SectionLine("", ConsoleColor.Gray)

        If isOk Then
            SectionLine("      STATUS  ...  [ OK ]  GOOD", ConsoleColor.Gray)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("      Device is in healthy working condition.", ConsoleColor.Gray)
        ElseIf isBad Then
            SectionLine("      STATUS  ...  [ !! ]  FAILED", ConsoleColor.DarkRed)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("      Device is reporting imminent failure.", ConsoleColor.DarkRed)
        Else
            SectionLine("      STATUS  ...  [ ?? ]  UNKNOWN", ConsoleColor.DarkYellow)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("      The device did not return a clear health status.", ConsoleColor.DarkYellow)
        End If

        SectionLine("", ConsoleColor.Gray)
        SectionBottom(hdrColor)

        Dim offline As String = FindField(raw, New String() {"Offline data collection status"})
        Dim autoOff As String = FindField(raw, New String() {"Auto Offline Data Collection"})
        Dim secs As String = FindField(raw, New String() {"Total time to complete Offline"})
        Dim cap As String = FindField(raw, New String() {"SMART capabilities"})

        If offline IsNot Nothing OrElse autoOff IsNot Nothing OrElse secs IsNot Nothing OrElse cap IsNot Nothing Then
            Console.WriteLine()
            SectionTop("SMART CAPABILITIES", ConsoleColor.Gray)
            If offline IsNot Nothing Then PrintFieldLine("Offline", offline)
            If autoOff IsNot Nothing Then PrintFieldLine("Auto Offline", autoOff)
            If secs IsNot Nothing Then PrintFieldLine("Collection", secs)
            If cap IsNot Nothing Then PrintFieldLine("Features", cap)
            SectionBottom(ConsoleColor.Gray)
        End If
    End Sub

    Private Sub DoShowTemperature(ByVal arg As String)
        Dim dev As String
        Try
            dev = ResolveDevice(arg)
        Catch ex As Exception
            PrintError(ex.Message) : Return
        End Try

        Dim raw As String = GetFullData(dev)
        ShowTemperatureSection(raw)
    End Sub

    Private Sub ShowTemperatureSection(ByVal raw As String)
        Dim driveTemp As String = Nothing
        Dim airflowTemp As String = Nothing
        Dim minV As String = Nothing
        Dim maxV As String = Nothing

        Dim inAttr As Boolean = False
        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.Length = 0 Then Continue For

            If t.StartsWith("ID# ATTRIBUTE_NAME") Then
                inAttr = True
                Continue For
            End If

            If inAttr Then
                If Not Char.IsDigit(t.Chars(0)) Then
                    inAttr = False
                    Continue For
                End If

                Dim sp() As String = Regex.Split(t, "\s+")
                If sp.Length < 10 Then Continue For

                Dim id As Integer = 0
                Integer.TryParse(sp(0), id)

                Dim rawVal As String = ""
                Dim i As Integer
                For i = 9 To sp.Length - 1
                    If rawVal.Length > 0 Then rawVal &= " "
                    rawVal &= sp(i)
                Next

                If id = 194 Then
                    driveTemp = FirstToken(rawVal) & " C"
                ElseIf id = 190 Then
                    airflowTemp = FirstToken(rawVal) & " C"
                End If

                If id = 194 OrElse id = 190 Then
                    Dim m As Match = Regex.Match(rawVal, "Min/Max\s+(\d+)/(\d+)")
                    If m.Success Then
                        minV = m.Groups(1).Value & " C"
                        maxV = m.Groups(2).Value & " C"
                    End If
                End If
            End If
        Next

        Console.WriteLine()
        SectionTop("TEMPERATURE", ConsoleColor.Gray)

        If driveTemp Is Nothing AndAlso airflowTemp Is Nothing Then
            SectionLine("  No temperature data available on this device.", ConsoleColor.DarkGray)
        Else
            SectionLine("", ConsoleColor.Gray)
            If driveTemp IsNot Nothing Then
                Dim col As ConsoleColor = TempColor(driveTemp)
                SectionLine("   Drive Temperature        " & driveTemp, col)
            End If
            If airflowTemp IsNot Nothing AndAlso airflowTemp <> driveTemp Then
                Dim col As ConsoleColor = TempColor(airflowTemp)
                SectionLine("   Airflow Temperature      " & airflowTemp, col)
            End If
            If minV IsNot Nothing Then
                SectionLine("   Historical Low           " & minV, ConsoleColor.DarkGray)
            End If
            If maxV IsNot Nothing Then
                Dim col2 As ConsoleColor = TempColor(maxV)
                SectionLine("   Historical High          " & maxV, col2)
            End If
            SectionLine("", ConsoleColor.Gray)
        End If

        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Function TempColor(ByVal tempText As String) As ConsoleColor
        Dim s As String = tempText
        Dim sp As Integer = s.IndexOf(" "c)
        If sp > 0 Then s = s.Substring(0, sp)
        Dim t As Integer = 0
        Integer.TryParse(s, t)
        If t >= 55 Then Return ConsoleColor.DarkRed
        If t >= 45 Then Return ConsoleColor.DarkYellow
        If t > 0 Then Return ConsoleColor.Gray
        Return ConsoleColor.DarkGray
    End Function

    Private Function FirstToken(ByVal s As String) As String
        If s Is Nothing Then Return "-"
        Dim sp As Integer = s.IndexOf(" "c)
        If sp > 0 Then Return s.Substring(0, sp)
        Return s
    End Function

    Private Sub DoShowDetail(ByVal arg As String)
        Dim dev As String
        Try
            dev = ResolveDevice(arg)
        Catch ex As Exception
            PrintError(ex.Message) : Return
        End Try

        Dim raw As String = GetFullData(dev)
        ShowSmartTable(raw)
    End Sub

    Private Sub ShowSmartTable(ByVal raw As String)
        Dim rows As New List(Of String())()
        Dim inAttr As Boolean = False
        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.Length = 0 Then Continue For

            If t.StartsWith("ID# ATTRIBUTE_NAME") Then
                inAttr = True
                Continue For
            End If

            If inAttr Then
                If Not Char.IsDigit(t.Chars(0)) Then
                    inAttr = False
                    Continue For
                End If

                Dim sp() As String = Regex.Split(t, "\s+")
                If sp.Length < 10 Then Continue For

                Dim rawVal As String = ""
                Dim i As Integer
                For i = 9 To sp.Length - 1
                    If rawVal.Length > 0 Then rawVal &= " "
                    rawVal &= sp(i)
                Next

                rows.Add(New String() {sp(0), sp(1), sp(3), sp(5), sp(8), rawVal})
            End If
        Next

        Console.WriteLine()
        SectionTop("S.M.A.R.T. ATTRIBUTE TABLE", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)

        Dim hdr As String = "  ID    ATTRIBUTE              VAL  THR  FLAG   RAW"
        SectionLine(hdr, ConsoleColor.DarkGray)
        SectionLine("  " & New String("-"c, 54), ConsoleColor.DarkGray)

        For Each r As String() In rows
            Dim id As Integer = Integer.Parse(r(0))
            Dim nm As String = r(1).Replace("_"c, " "c)
            Dim value As Integer = 0
            Integer.TryParse(r(2), value)
            Dim thresh As Integer = 0
            Integer.TryParse(r(3), thresh)
            Dim whenFailed As String = r(4)
            Dim rawVal As String = r(5)

            Dim status As String = AttrStatus(id, nm, value, thresh, whenFailed, rawVal)
            Dim col As ConsoleColor = StatusColor(status)
            Dim rawDisplay As String = FormatRawValue(nm, rawVal)

            Dim shortName As String = nm
            If shortName.Length > 20 Then shortName = shortName.Substring(0, 20)

            Dim flag As String = StatusBadge(status)

            Dim line As String = "  " & id.ToString().PadLeft(3) & "   " & _
                                 shortName.PadRight(20) & "  " & _
                                 value.ToString().PadLeft(3) & "  " & _
                                 thresh.ToString().PadLeft(3) & "  " & _
                                 flag.PadRight(5) & "  " & rawDisplay
            SectionLine(line, col)
        Next

        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Sub DoShowAll(ByVal arg As String)
        Dim dev As String
        Try
            dev = ResolveDevice(arg)
        Catch ex As Exception
            PrintError(ex.Message) : Return
        End Try

        DoShowInfo(arg)
        DoShowStatus(arg)
        DoShowTemperature(arg)
        DoShowDetail(arg)
        ShowErrorLog(GetFullData(dev))
        ShowSelfTestLog(GetFullData(dev))
    End Sub

    Private Sub DoProbe(ByVal arg As String, ByVal action As String)
        Dim dev As String
        Try
            dev = ResolveDevice(arg)
        Catch ex As Exception
            PrintError(ex.Message) : Return
        End Try

        If action Is Nothing OrElse action.Length = 0 Then
            PrintProbeUsage()
            Return
        End If

        Select Case action.ToLower()
            Case "quick", "short"
                LaunchProbe(dev, "short")
            Case "deep", "long", "full"
                LaunchProbe(dev, "long")
            Case "report", "log", "history"
                ShowProbeReport(dev)
            Case "stop", "halt", "abort", "cancel"
                StopProbe(dev)
            Case Else
                PrintProbeUsage()
        End Select
    End Sub

    Private Sub PrintProbeUsage()
        Console.WriteLine()
        SectionTop("DIAGNOSTIC PROBE - USAGE", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("  probe <ID> quick    -  Launch a quick surface scan", ConsoleColor.Gray)
        SectionLine("  probe <ID> deep     -  Launch a deep full scan", ConsoleColor.Gray)
        SectionLine("  probe <ID> report   -  Show scan history", ConsoleColor.Gray)
        SectionLine("  probe <ID> stop     -  Abort running scan", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("  Example:  probe 0 quick", ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Sub LaunchProbe(ByVal dev As String, ByVal kind As String)
        Dim devArgs As String = GetDeviceArgs(dev)
        Dim arg As String = "-t short " & devArgs
        Dim label As String = "QUICK SURFACE SCAN"
        If kind = "long" Then
            arg = "-t long " & devArgs
            label = "DEEP FULL SCAN"
        End If

        Dim raw As String = InvokeSmartctl(arg)

        Dim launched As Boolean = False
        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.ToLower().IndexOf("testing has begun") >= 0 Then launched = True
            If t.ToLower().IndexOf("successful") >= 0 Then launched = True
        Next

        If Not launched Then
            Console.WriteLine()
            SectionTop("DIAGNOSTIC PROBE", ConsoleColor.DarkRed)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("   [ XX ]  The device refused to start the probe.", ConsoleColor.DarkRed)
            SectionLine("           Please verify administrative privileges", ConsoleColor.DarkGray)
            SectionLine("           and try again.", ConsoleColor.DarkGray)
            SectionLine("", ConsoleColor.Gray)
            SectionBottom(ConsoleColor.DarkRed)
            Return
        End If

        ShowLiveProgress(dev, label)

        _cachedData = Nothing
        _cachedDev = Nothing
    End Sub

    Private Sub ShowLiveProgress(ByVal dev As String, ByVal label As String)
        Dim model As String = GetDeviceModel(dev)
        Dim dtype As String = GetDeviceType(dev)

        Console.WriteLine()
        SectionTop("DIAGNOSTIC PROBE - LIVE", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   Target          :  " & model, ConsoleColor.Gray)
        If dtype.Length > 0 Then
            SectionLine("   Device Type     :  " & dtype, ConsoleColor.DarkGray)
        End If
        SectionLine("   Probe Type      :  " & label, ConsoleColor.Gray)
        SectionLine("   Started         :  " & DateTime.Now.ToString("ddd MMM d HH:mm:ss yyyy"), ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)

        Dim progressRow As Integer = Console.CursorTop
        SectionLine("   Progress        :  [..............................]   0%", ConsoleColor.DarkYellow)
        Dim remainingRow As Integer = Console.CursorTop
        SectionLine("   Remaining       :  calculating...", ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)
        Dim resultRow As Integer = Console.CursorTop
        SectionLine("   Result          :  probe is running...", ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   Press ESC to abort the probe.", ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)

        Dim startTime As DateTime = DateTime.Now
        Dim finalDesc As String = ""
        Dim finalCode As Integer = -1
        Dim aborted As Boolean = False

        While True
            Dim pct As Integer = 0
            Dim done As Boolean = False
            Dim code As Integer = -1
            Dim desc As String = ""

            GetProbeProgress(dev, pct, done, code, desc)

            Dim bar As String = MakeProgressBar(pct, 30)
            Dim pctStr As String = pct.ToString().PadLeft(3) & "%"
            Dim col As ConsoleColor = ConsoleColor.DarkYellow
            If done Then col = ConsoleColor.Gray

            WriteSectionLineAt(progressRow, "   Progress        :  [" & bar & "] " & pctStr, col)

            Dim remText As String = "calculating..."
            If pct > 0 AndAlso Not done Then
                Dim elapsed As TimeSpan = DateTime.Now.Subtract(startTime)
                Dim totalSec As Double = elapsed.TotalSeconds * 100 / pct
                Dim remSec As Double = totalSec - elapsed.TotalSeconds
                If remSec < 0 Then remSec = 0
                remText = FormatTimeSpan(TimeSpan.FromSeconds(remSec)) & " remaining"
            ElseIf done Then
                remText = "completed"
            End If
            WriteSectionLineAt(remainingRow, "   Remaining       :  " & remText, ConsoleColor.DarkGray)

            If done Then
                finalDesc = desc
                finalCode = code
                Exit While
            End If

            Try
                If Console.KeyAvailable Then
                    Dim k As ConsoleKeyInfo = Console.ReadKey(True)
                    If k.Key = ConsoleKey.Escape Then
                        InvokeSmartctl("-X " & GetDeviceArgs(dev))
                        aborted = True
                        Exit While
                    End If
                End If
            Catch
            End Try

            Thread.Sleep(1000)
        End While

        Dim resColor As ConsoleColor = ConsoleColor.Gray
        Dim resText As String = ""

        If aborted Then
            resColor = ConsoleColor.DarkYellow
            resText = "[ !! ]  Aborted by user"
        ElseIf finalCode = 0 Then
            resColor = ConsoleColor.Gray
            resText = "[ OK ]  Completed without error"
        ElseIf finalCode > 0 Then
            resColor = ConsoleColor.DarkRed
            resText = "[ XX ]  Probe failed"
        Else
            resColor = ConsoleColor.DarkGray
            resText = "[ -- ]  Probe completed with unknown status"
        End If

        WriteSectionLineAt(resultRow, "   Result          :  " & resText, resColor)

        Dim elapsedTotal As TimeSpan = DateTime.Now.Subtract(startTime)
        WriteSectionLineAt(resultRow + 1, "   Elapsed         :  " & FormatTimeSpan(elapsedTotal), ConsoleColor.DarkGray)

        Try
            Console.SetCursorPosition(0, resultRow + 5)
        Catch
        End Try
    End Sub

    Private Function FormatTimeSpan(ByVal t As TimeSpan) As String
        If t.TotalHours >= 1 Then
            Return String.Format("{0}h {1}m {2}s", CInt(t.TotalHours), t.Minutes, t.Seconds)
        ElseIf t.TotalMinutes >= 1 Then
            Return String.Format("{0}m {1}s", t.Minutes, t.Seconds)
        Else
            Return String.Format("{0}s", t.Seconds)
        End If
    End Function

    Private Function MakeProgressBar(ByVal pct As Integer, ByVal width As Integer) As String
        If pct < 0 Then pct = 0
        If pct > 100 Then pct = 100
        Dim filled As Integer = CInt(pct * width / 100)
        Dim sb As New StringBuilder()
        For i As Integer = 1 To width
            If i <= filled Then
                sb.Append("#"c)
            Else
                sb.Append("."c)
            End If
        Next
        Return sb.ToString()
    End Function

    Private Sub GetProbeProgress(ByVal dev As String, ByRef pct As Integer, ByRef done As Boolean, _
                                  ByRef code As Integer, ByRef desc As String)
        pct = 0
        done = False
        code = -1
        desc = ""

        Dim raw As String = InvokeSmartctl("-c " & GetDeviceArgs(dev))
        Dim lines() As String = GetLines(raw)

        For i As Integer = 0 To lines.Length - 1
            Dim t As String = lines(i).Trim()
            If t.StartsWith("Self-test execution status:") Then
                Dim m As Match = Regex.Match(t, "\(\s*(\d+)\s*\)")
                If m.Success Then
                    code = Integer.Parse(m.Groups(1).Value)
                    Dim close As Integer = t.IndexOf(")"c)
                    If close >= 0 AndAlso close + 1 < t.Length Then
                        desc = t.Substring(close + 1).Trim()
                    End If
                End If

                If i + 1 < lines.Length Then
                    Dim m2 As Match = Regex.Match(lines(i + 1), "(\d+)%\s+of test remaining")
                    If m2.Success Then
                        Dim remPct As Integer = Integer.Parse(m2.Groups(1).Value)
                        pct = 100 - remPct
                    End If
                End If
                Exit For
            End If
        Next

        If code = 0 Then
            done = True
            pct = 100
        ElseIf code >= 240 AndAlso code <= 255 Then
            done = False
            If pct = 0 Then pct = 1
        ElseIf code > 0 AndAlso code < 240 Then
            done = True
            pct = 100
        End If
    End Sub

    Private Sub WriteSectionLineAt(ByVal row As Integer, ByVal text As String, ByVal col As ConsoleColor)
        Dim padded As String = text
        If padded.Length < 78 Then padded = padded.PadRight(78)
        Try
            Console.SetCursorPosition(0, row)
        Catch
            Return
        End Try
        Console.ForegroundColor = col
        Console.Write("  " & padded)
        Console.ResetColor()
    End Sub

    Private Sub StopProbe(ByVal dev As String)
        InvokeSmartctl("-X " & GetDeviceArgs(dev))

        Dim model As String = GetDeviceModel(dev)

        Console.WriteLine()
        SectionTop("DIAGNOSTIC PROBE", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   Target  :  " & model, ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("      Abort request transmitted to the device.", ConsoleColor.DarkYellow)
        SectionLine("      Any running scan should stop within a few seconds.", ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Sub ShowProbeReport(ByVal dev As String)
        Dim raw As String = GetFullData(dev)
        Dim model As String = GetDeviceModel(dev)

        Console.WriteLine()
        SectionTop("PROBE HISTORY", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   Target  :  " & model, ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   SEQ   KIND                RESULT             LIFE", ConsoleColor.DarkGray)
        SectionLine("   " & New String("-"c, 52), ConsoleColor.DarkGray)

        Dim collecting As Boolean = False
        Dim found As Boolean = False

        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.StartsWith("Num  Test_Description") Then
                collecting = True
                Continue For
            End If

            If collecting Then
                If t.Length = 0 Then
                    collecting = False
                    Continue For
                End If
                If Not t.StartsWith("#") Then
                    collecting = False
                    Continue For
                End If

                found = True

                Dim m As Match = Regex.Match(t, "^#\s*(\d+)\s+(.+?)\s{2,}(.+?)\s+(\d+)%\s+(\d+)\s+(.+)$")
                If m.Success Then
                    Dim seq As String = m.Groups(1).Value.PadLeft(3)
                    Dim kind As String = m.Groups(2).Value
                    Dim res As String = m.Groups(3).Value
                    Dim life As String = m.Groups(4).Value & "%"

                    If kind.ToLower().IndexOf("short") >= 0 Then kind = "Quick scan"
                    If kind.ToLower().IndexOf("long") >= 0 Then kind = "Deep scan"
                    If kind.ToLower().IndexOf("conveyance") >= 0 Then kind = "Transit scan"

                    If res.ToLower().IndexOf("without error") >= 0 Then res = "Passed"
                    If res.ToLower().IndexOf("read failure") >= 0 Then res = "READ FAIL"
                    If res.ToLower().IndexOf("completed: unknown") >= 0 Then res = "Unknown"
                    If res.ToLower().IndexOf("in progress") >= 0 Then res = "In progress"

                    Dim col As ConsoleColor = ConsoleColor.Gray
                    If res.ToLower().IndexOf("fail") >= 0 Then col = ConsoleColor.DarkRed
                    If res.ToLower().IndexOf("progress") >= 0 Then col = ConsoleColor.DarkYellow
                    If res.ToLower().IndexOf("unknown") >= 0 Then col = ConsoleColor.DarkGray

                    Dim line As String = "   #" & seq & "   " & kind.PadRight(18) & "  " & _
                                         res.PadRight(15) & "  " & life
                    SectionLine(line, col)
                End If
            End If
        Next

        If Not found Then
            SectionLine("   No probe records found on this device.", ConsoleColor.DarkGray)
        End If

        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Sub DoExport(ByVal arg As String, ByVal format As String, ByVal filePath As String)
        Dim dev As String
        Try
            dev = ResolveDevice(arg)
        Catch ex As Exception
            PrintError(ex.Message) : Return
        End Try

        If format Is Nothing OrElse format.Length = 0 Then
            PrintExportUsage()
            Return
        End If

        Dim fmt As String = format.ToLower()
        If fmt <> "txt" AndAlso fmt <> "json" AndAlso fmt <> "html" Then
            PrintExportUsage()
            Return
        End If

        Dim model As String = GetDeviceModel(dev)
        Dim safeName As String = SanitizeFileName(model)
        Dim ts As String = DateTime.Now.ToString("yyyyMMdd_HHmmss")

        Dim target As String = filePath
        If target Is Nothing OrElse target.Length = 0 Then
            target = Path.Combine(Environment.CurrentDirectory, safeName & "_" & ts & "." & fmt)
        Else
            If Directory.Exists(target) Then
                target = Path.Combine(target, safeName & "_" & ts & "." & fmt)
            End If
        End If

        Dim raw As String = GetFullData(dev)
        Dim infoRows As List(Of String()) = BuildInfoRows(raw)
        Dim smartRows As List(Of String()) = BuildSmartRows(raw)
        Dim health As String = BuildHealthText(raw)
        Dim tempText As String = BuildTempText(raw)
        Dim errText As String = BuildErrorText(raw)
        Dim selfTestText As String = BuildSelfTestText(raw)
        Dim dtype As String = GetDeviceType(dev)

        Try
            Dim dir As String = Path.GetDirectoryName(target)
            If dir IsNot Nothing AndAlso dir.Length > 0 AndAlso Not Directory.Exists(dir) Then
                Directory.CreateDirectory(dir)
            End If

            If fmt = "txt" Then
                File.WriteAllText(target, ExportTxtBody(model, dtype, infoRows, health, tempText, smartRows, errText, selfTestText), Encoding.UTF8)
            ElseIf fmt = "json" Then
                File.WriteAllText(target, ExportJsonBody(model, dtype, infoRows, health, tempText, smartRows, errText, selfTestText), Encoding.UTF8)
            Else
                File.WriteAllText(target, ExportHtmlBody(model, dtype, infoRows, health, tempText, smartRows, errText, selfTestText), Encoding.UTF8)
            End If

            Console.WriteLine()
            SectionTop("EXPORT COMPLETE", ConsoleColor.Gray)
            SectionLine("", ConsoleColor.Gray)
            SectionLine("   Format        :  " & fmt.ToUpper(), ConsoleColor.Gray)
            SectionLine("   Target        :  " & model, ConsoleColor.Gray)
            SectionLine("   File          :  " & target, ConsoleColor.White)
            SectionLine("", ConsoleColor.Gray)
            SectionBottom(ConsoleColor.Gray)
        Catch ex As Exception
            PrintError("The report could not be saved to disk.")
        End Try
    End Sub

    Private Sub PrintExportUsage()
        Console.WriteLine()
        SectionTop("EXPORT - USAGE", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("  export <ID> txt  [path]   -  Export plain text report", ConsoleColor.Gray)
        SectionLine("  export <ID> json [path]   -  Export structured JSON data", ConsoleColor.Gray)
        SectionLine("  export <ID> html [path]   -  Export HTML report", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("  Examples:", ConsoleColor.DarkGray)
        SectionLine("    export 0 txt", ConsoleColor.DarkGray)
        SectionLine("    export 0 json C:\Reports", ConsoleColor.DarkGray)
        SectionLine("    export 1 html report.html", ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Function SanitizeFileName(ByVal name As String) As String
        If name Is Nothing OrElse name.Length = 0 Then Return "device"
        Dim bad() As Char = Path.GetInvalidFileNameChars()
        Dim sb As New StringBuilder()
        For i As Integer = 0 To name.Length - 1
            Dim c As Char = name.Chars(i)
            Dim ok As Boolean = True
            For j As Integer = 0 To bad.Length - 1
                If c = bad(j) Then
                    ok = False
                    Exit For
                End If
            Next
            If ok Then sb.Append(c) Else sb.Append("_"c)
        Next
        Dim result As String = sb.ToString().Trim()
        If result.Length = 0 Then result = "device"
        If result.Length > 60 Then result = result.Substring(0, 60)
        Return result
    End Function

    Private Function BuildInfoRows(ByVal raw As String) As List(Of String())
        Dim rows As New List(Of String())()

        Dim family As String = FindField(raw, New String() {"Model Family"})
        Dim brand As String = ExtractBrand(family)
        If brand Is Nothing OrElse brand.Length = 0 Then brand = "Unknown"

        rows.Add(New String() {"Brand", brand})
        rows.Add(New String() {"Model", SafeVal(FindField(raw, New String() {"Device Model", "Model Number", "Product", "Model"}))})
        rows.Add(New String() {"Serial Number", SafeVal(FindField(raw, New String() {"Serial Number", "Serial number"}))})
        rows.Add(New String() {"Firmware", SafeVal(FindField(raw, New String() {"Firmware Version", "Revision"}))})
        rows.Add(New String() {"LU WWN", SafeVal(FindField(raw, New String() {"LU WWN Device Id", "Logical Unit id"}))})
        rows.Add(New String() {"Capacity", SafeVal(FindField(raw, New String() {"User Capacity", "Total NVM Capacity", "Namespace 1 Size/Capacity"}))})
        rows.Add(New String() {"Sector Size", SafeVal(FindField(raw, New String() {"Sector Size", "Sector Sizes", "Logical Sector Size"}))})
        rows.Add(New String() {"Form Factor", SafeVal(FindField(raw, New String() {"Form Factor"}))})
        rows.Add(New String() {"Rotation Rate", SafeVal(FindField(raw, New String() {"Rotation Rate"}))})
        rows.Add(New String() {"ATA Version", SafeVal(FindField(raw, New String() {"ATA Version is"}))})
        rows.Add(New String() {"SATA Version", SafeVal(FindField(raw, New String() {"SATA Version is"}))})
        rows.Add(New String() {"Local Time", SafeVal(FindField(raw, New String() {"Local Time is"}))})
        rows.Add(New String() {"SMART Support", SafeVal(FindField(raw, New String() {"SMART support is"}))})
        rows.Add(New String() {"TRIM Support", SafeVal(FindField(raw, New String() {"TRIM Command support"}))})
        rows.Add(New String() {"NCQ Support", SafeVal(FindField(raw, New String() {"NCQ feature is", "NCQ (depth 0/32)"}))})
        rows.Add(New String() {"APM Support", SafeVal(FindField(raw, New String() {"APM feature is", "APM level"}))})
        rows.Add(New String() {"Write Verify", SafeVal(FindField(raw, New String() {"Write-Read-Verify feature is"}))})

        Return rows
    End Function

    Private Function SafeVal(ByVal v As String) As String
        If v Is Nothing OrElse v.Length = 0 Then Return "-"
        Return v
    End Function

    Private Function BuildSmartRows(ByVal raw As String) As List(Of String())
        Dim rows As New List(Of String())()
        Dim inAttr As Boolean = False
        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.Length = 0 Then Continue For

            If t.StartsWith("ID# ATTRIBUTE_NAME") Then
                inAttr = True
                Continue For
            End If

            If inAttr Then
                If Not Char.IsDigit(t.Chars(0)) Then
                    inAttr = False
                    Continue For
                End If

                Dim sp() As String = Regex.Split(t, "\s+")
                If sp.Length < 10 Then Continue For

                Dim rawVal As String = ""
                Dim i As Integer
                For i = 9 To sp.Length - 1
                    If rawVal.Length > 0 Then rawVal &= " "
                    rawVal &= sp(i)
                Next

                Dim id As Integer = Integer.Parse(sp(0))
                Dim nm As String = sp(1).Replace("_"c, " "c)
                Dim value As Integer = 0
                Integer.TryParse(sp(3), value)
                Dim worst As String = sp(4)
                Dim thresh As Integer = 0
                Integer.TryParse(sp(5), thresh)
                Dim whenFailed As String = sp(8)

                Dim status As String = AttrStatus(id, nm, value, thresh, whenFailed, rawVal)
                Dim rawDisplay As String = FormatRawValue(nm, rawVal)

                rows.Add(New String() {sp(0), nm, sp(3), worst, sp(5), status, rawDisplay})
            End If
        Next
        Return rows
    End Function

    Private Function BuildHealthText(ByVal raw As String) As String
        Dim result As String = FindField(raw, New String() {"SMART overall-health self-assessment test result"})
        If result Is Nothing Then result = FindField(raw, New String() {"SMART Health Status"})
        If result Is Nothing Then Return "UNKNOWN"
        Dim up As String = result.ToUpper()
        If up.IndexOf("PASSED") >= 0 OrElse up.IndexOf("OK") >= 0 Then Return "GOOD"
        If up.IndexOf("FAILED") >= 0 Then Return "FAILED"
        Return result
    End Function

    Private Function BuildTempText(ByVal raw As String) As String
        Dim driveTemp As String = Nothing
        Dim airflowTemp As String = Nothing
        Dim minV As String = Nothing
        Dim maxV As String = Nothing

        Dim inAttr As Boolean = False
        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.Length = 0 Then Continue For
            If t.StartsWith("ID# ATTRIBUTE_NAME") Then
                inAttr = True
                Continue For
            End If
            If inAttr Then
                If Not Char.IsDigit(t.Chars(0)) Then
                    inAttr = False
                    Continue For
                End If
                Dim sp() As String = Regex.Split(t, "\s+")
                If sp.Length < 10 Then Continue For
                Dim id As Integer = 0
                Integer.TryParse(sp(0), id)
                Dim rawVal As String = ""
                Dim i As Integer
                For i = 9 To sp.Length - 1
                    If rawVal.Length > 0 Then rawVal &= " "
                    rawVal &= sp(i)
                Next
                If id = 194 Then driveTemp = FirstToken(rawVal) & " C"
                If id = 190 Then airflowTemp = FirstToken(rawVal) & " C"
                If id = 194 OrElse id = 190 Then
                    Dim m As Match = Regex.Match(rawVal, "Min/Max\s+(\d+)/(\d+)")
                    If m.Success Then
                        minV = m.Groups(1).Value & " C"
                        maxV = m.Groups(2).Value & " C"
                    End If
                End If
            End If
        Next

        If driveTemp Is Nothing AndAlso airflowTemp Is Nothing Then Return "N/A"
        Dim sb As New StringBuilder()
        If driveTemp IsNot Nothing Then sb.Append("Drive: " & driveTemp)
        If airflowTemp IsNot Nothing AndAlso airflowTemp <> driveTemp Then
            If sb.Length > 0 Then sb.Append(" | ")
            sb.Append("Airflow: " & airflowTemp)
        End If
        If minV IsNot Nothing Then sb.Append(" | Min: " & minV)
        If maxV IsNot Nothing Then sb.Append(" | Max: " & maxV)
        Return sb.ToString()
    End Function

    Private Function BuildErrorText(ByVal raw As String) As String
        Dim errCount As String = Nothing
        Dim noErrors As Boolean = False
        Dim hasLog As Boolean = False

        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.StartsWith("ATA Error Count:") Then errCount = t.Substring("ATA Error Count:".Length).Trim()
            If t.StartsWith("SMART Error Log Version:") Then hasLog = True
            If hasLog AndAlso t.StartsWith("No Errors Logged") Then noErrors = True
        Next

        If noErrors Then Return "No errors logged"
        If errCount IsNot Nothing Then Return errCount & " error(s) recorded"
        If Not hasLog Then Return "Not provided by device"
        Return "Unknown"
    End Function

    Private Function BuildSelfTestText(ByVal raw As String) As String
        Dim sb As New StringBuilder()
        Dim collecting As Boolean = False
        Dim count As Integer = 0
        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.StartsWith("Num  Test_Description") Then
                collecting = True
                Continue For
            End If
            If collecting Then
                If t.Length = 0 OrElse Not t.StartsWith("#") Then
                    collecting = False
                    Continue For
                End If
                If count >= 5 Then Continue For
                If sb.Length > 0 Then sb.Append(vbLf)
                sb.Append(t)
                count += 1
            End If
        Next
        Return sb.ToString()
    End Function

    Private Function CreditLine() As String
        Return "(c) 2015 - " & DateTime.Now.Year.ToString() & ". Ari Sohandri Putra. All Rights Reserved."
    End Function

    Private Function CreditSite() As String
        Return "www.pongo.my.id"
    End Function

    Private Function ExportTxtBody(ByVal model As String, ByVal dtype As String, ByVal infoRows As List(Of String()), _
                                    ByVal health As String, ByVal tempText As String, ByVal smartRows As List(Of String()), _
                                    ByVal errText As String, ByVal selfTestText As String) As String
        Dim sb As New StringBuilder()
        sb.AppendLine("PHD - PONGO HARD DRIVE REPORT")
        sb.AppendLine("Generated : " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
        sb.AppendLine("Device    : " & model & " (" & dtype & ")")
        sb.AppendLine(New String("="c, 60))
        sb.AppendLine()

        sb.AppendLine("DEVICE IDENTITY")
        sb.AppendLine(New String("-"c, 60))
        For Each r As String() In infoRows
            sb.AppendLine("  " & r(0).PadRight(18) & " : " & r(1))
        Next
        sb.AppendLine()

        sb.AppendLine("HEALTH STATUS")
        sb.AppendLine(New String("-"c, 60))
        sb.AppendLine("  Overall  : " & health)
        sb.AppendLine("  Temp     : " & tempText)
        sb.AppendLine()

        sb.AppendLine("S.M.A.R.T. ATTRIBUTES")
        sb.AppendLine(New String("-"c, 60))
        sb.AppendLine("  ID    ATTRIBUTE              VAL  WORST  THR  STATUS  RAW")
        For Each r As String() In smartRows
            sb.AppendLine("  " & r(0).PadLeft(3) & "   " & r(1).PadRight(20) & "  " & _
                          r(2).PadLeft(3) & "  " & r(3).PadLeft(5) & "  " & _
                          r(4).PadLeft(3) & "  " & r(5).PadRight(6) & "  " & r(6))
        Next
        sb.AppendLine()

        sb.AppendLine("ERROR LOG")
        sb.AppendLine(New String("-"c, 60))
        sb.AppendLine("  " & errText)
        sb.AppendLine()

        sb.AppendLine("SELF-TEST HISTORY")
        sb.AppendLine(New String("-"c, 60))
        If selfTestText.Length = 0 Then
            sb.AppendLine("  No self-test history recorded.")
        Else
            For Each ln As String In selfTestText.Split(ChrW(10))
                sb.AppendLine("  " & ln)
            Next
        End If
        sb.AppendLine()

        sb.AppendLine(New String("="c, 60))
        sb.AppendLine(CreditLine())
        sb.AppendLine(CreditSite())

        Return sb.ToString()
    End Function

    Private Function ExportJsonBody(ByVal model As String, ByVal dtype As String, ByVal infoRows As List(Of String()), _
                                     ByVal health As String, ByVal tempText As String, ByVal smartRows As List(Of String()), _
                                     ByVal errText As String, ByVal selfTestText As String) As String
        Dim sb As New StringBuilder()
        sb.AppendLine("{")
        sb.AppendLine("  ""program"": ""PHD - Pongo Hard Drive"",")
        sb.AppendLine("  ""generated"": """ & JsonEscape(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")) & """,")
        sb.AppendLine("  ""copyright"": """ & JsonEscape(CreditLine()) & """,")
        sb.AppendLine("  ""website"": """ & JsonEscape(CreditSite()) & """,")
        sb.AppendLine("  ""model"": """ & JsonEscape(model) & """,")
        sb.AppendLine("  ""device_type"": """ & JsonEscape(dtype) & """,")
        sb.AppendLine("  ""health"": """ & JsonEscape(health) & """,")
        sb.AppendLine("  ""temperature"": """ & JsonEscape(tempText) & """,")
        sb.AppendLine("  ""error_log"": """ & JsonEscape(errText) & """,")

        sb.AppendLine("  ""identity"": {")
        For i As Integer = 0 To infoRows.Count - 1
            Dim comma As String = ","
            If i = infoRows.Count - 1 Then comma = ""
            sb.AppendLine("    """ & JsonEscape(JsonKey(infoRows(i)(0))) & """: """ & JsonEscape(infoRows(i)(1)) & """" & comma)
        Next
        sb.AppendLine("  },")

        sb.AppendLine("  ""attributes"": [")
        For i As Integer = 0 To smartRows.Count - 1
            Dim r As String() = smartRows(i)
            Dim comma As String = ","
            If i = smartRows.Count - 1 Then comma = ""
            sb.AppendLine("    {")
            sb.AppendLine("      ""id"": " & r(0) & ",")
            sb.AppendLine("      ""name"": """ & JsonEscape(r(1)) & """,")
            sb.AppendLine("      ""value"": " & r(2) & ",")
            sb.AppendLine("      ""worst"": " & r(3) & ",")
            sb.AppendLine("      ""threshold"": " & r(4) & ",")
            sb.AppendLine("      ""status"": """ & JsonEscape(r(5)) & """,")
            sb.AppendLine("      ""raw"": """ & JsonEscape(r(6)) & """")
            sb.AppendLine("    }" & comma)
        Next
        sb.AppendLine("  ],")

        sb.AppendLine("  ""self_test_history"": [")
        Dim stLines() As String = New String() {}
        If selfTestText.Length > 0 Then stLines = selfTestText.Split(ChrW(10))
        For i As Integer = 0 To stLines.Length - 1
            Dim comma As String = ","
            If i = stLines.Length - 1 Then comma = ""
            sb.AppendLine("    """ & JsonEscape(stLines(i).Trim()) & """" & comma)
        Next
        sb.AppendLine("  ]")

        sb.AppendLine("}")
        Return sb.ToString()
    End Function

    Private Function JsonKey(ByVal s As String) As String
        If s Is Nothing Then Return ""
        Return s.Replace(" ", "_").ToLower()
    End Function

    Private Function JsonEscape(ByVal s As String) As String
        If s Is Nothing Then Return ""
        Dim sb As New StringBuilder()
        For i As Integer = 0 To s.Length - 1
            Dim c As Char = s.Chars(i)
            Select Case c
                Case """"c
                    sb.Append("\""")
                Case "\"c
                    sb.Append("\\")
                Case ChrW(8)
                    sb.Append("\b")
                Case ChrW(12)
                    sb.Append("\f")
                Case ChrW(10)
                    sb.Append("\n")
                Case ChrW(13)
                    sb.Append("\r")
                Case ChrW(9)
                    sb.Append("\t")
                Case Else
                    If AscW(c) < 32 Then
                        sb.Append("\u" & AscW(c).ToString("x4"))
                    Else
                        sb.Append(c)
                    End If
            End Select
        Next
        Return sb.ToString()
    End Function

    Private Function HtmlEscape(ByVal s As String) As String
        If s Is Nothing Then Return ""
        Return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("""", "&quot;")
    End Function

    Private Function ExportHtmlBody(ByVal model As String, ByVal dtype As String, ByVal infoRows As List(Of String()), _
                                 ByVal health As String, ByVal tempText As String, ByVal smartRows As List(Of String()), _
                                 ByVal errText As String, ByVal selfTestText As String) As String
        Dim sb As New StringBuilder()

        sb.AppendLine("<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">")
        sb.AppendLine("<html>")
        sb.AppendLine("<head>")
        sb.AppendLine("<meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8"">")
        sb.AppendLine("<meta name=""viewport"" content=""width=device-width, initial-scale=1"">")
        sb.AppendLine("<link rel=""icon"" type=""image/x-icon"" href=""../favicon.ico"">")
        sb.AppendLine("<title>PHD Report - " & HtmlEscape(model) & "</title>")
        sb.AppendLine("<style type=""text/css"">")
        sb.AppendLine("<!--")
        sb.AppendLine("body, td, th { font-family: Tahoma, Geneva, sans-serif; font-size: 13px; color: #000000; background-color: #FFFFFF; margin: 0; padding: 0; }")
        sb.AppendLine("a:link, a:visited { color: #0000FF; text-decoration: none; }")
        sb.AppendLine("a:hover { color: #FF0000; }")
        sb.AppendLine(".wrapper { width: 100%; background-color: #FFFFFF; padding: 16px 8px; }")
        sb.AppendLine(".report { max-width: 880px; margin: 0 auto; border: 1px solid #999999; background-color: #FFFFFF; }")
        sb.AppendLine(".masthead { background-color: #CCCCCC; padding: 12px 18px; border-bottom: 1px solid #999999; }")
        sb.AppendLine(".masthead td { font-family: Tahoma, Geneva, sans-serif; }")
        sb.AppendLine(".masthead .title { font-size: 14px; font-weight: bold; color: #000000; }")
        sb.AppendLine(".masthead .subtitle { font-size: 11px; color: #333333; }")
        sb.AppendLine(".masthead .credit { font-size: 11px; color: #333333; text-align: right; }")
        sb.AppendLine(".section { padding: 14px 18px; border-bottom: 1px solid #CCCCCC; }")
        sb.AppendLine(".section.last { border-bottom: 0; }")
        sb.AppendLine(".section h2 { font-family: Tahoma, Geneva, sans-serif; font-size: 13px; font-weight: bold; color: #000000; margin: 0 0 10px 0; padding: 0 0 6px 0; border-bottom: 1px solid #CCCCCC; text-transform: uppercase; letter-spacing: 1px; }")
        sb.AppendLine("table.kv { width: 100%; border-collapse: collapse; }")
        sb.AppendLine("table.kv td { padding: 5px 6px; border-bottom: 1px solid #EEEEEE; vertical-align: top; font-size: 12px; }")
        sb.AppendLine("table.kv td.k { color: #555555; width: 180px; }")
        sb.AppendLine("table.kv td.v { color: #000000; font-family: ""Courier New"", Courier, monospace; font-size: 12px; }")
        sb.AppendLine("table.data { width: 100%; border-collapse: collapse; font-size: 12px; }")
        sb.AppendLine("table.data th { text-align: left; padding: 6px 8px; background-color: #CCCCCC; border: 1px solid #999999; font-weight: bold; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; }")
        sb.AppendLine("table.data td { padding: 5px 8px; border: 1px solid #DDDDDD; font-family: ""Courier New"", Courier, monospace; font-size: 12px; color: #000000; background-color: #FFFFFF; }")
        sb.AppendLine("table.data tr:hover td { background-color: #F5F5F5; }")
        sb.AppendLine("td.id { text-align: right; color: #555555; width: 45px; }")
        sb.AppendLine("td.stat-ok { color: #006600; font-weight: bold; }")
        sb.AppendLine("td.stat-warn { color: #996600; font-weight: bold; }")
        sb.AppendLine("td.stat-bad { color: #990000; font-weight: bold; }")
        sb.AppendLine(".status-box { padding: 10px 12px; border: 1px solid #CCCCCC; background-color: #F9F9F9; margin-bottom: 10px; }")
        sb.AppendLine(".status-box .mark { display: inline-block; padding: 3px 10px; font-family: ""Courier New"", Courier, monospace; font-size: 12px; font-weight: bold; border: 1px solid #999999; background-color: #FFFFFF; margin-right: 8px; }")
        sb.AppendLine(".mark-good { color: #006600; }")
        sb.AppendLine(".mark-warn { color: #996600; }")
        sb.AppendLine(".mark-bad { color: #990000; }")
        sb.AppendLine(".status-box .label { font-size: 12px; color: #333333; }")
        sb.AppendLine(".pre { background-color: #F5F5F5; border: 1px solid #DDDDDD; padding: 8px 10px; font-family: ""Courier New"", Courier, monospace; font-size: 11px; color: #333333; white-space: pre-wrap; margin: 0; }")
        sb.AppendLine(".footer { background-color: #CCCCCC; padding: 10px 18px; border-top: 1px solid #999999; text-align: center; font-size: 11px; color: #333333; }")
        sb.AppendLine(".footer strong { font-weight: bold; }")
        sb.AppendLine("-->")
        sb.AppendLine("</style>")
        sb.AppendLine("</head>")
        sb.AppendLine("<body>")
        sb.AppendLine("<div class=""wrapper"">")
        sb.AppendLine("<div class=""report"">")

        sb.AppendLine("<div class=""masthead"">")
        sb.AppendLine("<table width=""100%"" border=""0"" cellpadding=""0"" cellspacing=""0"">")
        sb.AppendLine("<tr valign=""middle"">")
        sb.AppendLine("<td width=""70""><img src=""../logo.png"" width=""64"" alt=""PHD"" border=""0""></td>")
        sb.AppendLine("<td>")
        sb.AppendLine("<div class=""title"">Pongo Hard Drive &mdash; Diagnostic Report</div>")
        sb.AppendLine("<div class=""subtitle"">Free HDD/SSD Diagnostic Tools</div>")
        sb.AppendLine("</td>")
        sb.AppendLine("<td align=""right"" class=""credit"">")
        sb.AppendLine("" & HtmlEscape(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")) & "<br>")
        sb.AppendLine("www.pongo.my.id")
        sb.AppendLine("</td>")
        sb.AppendLine("</tr>")
        sb.AppendLine("</table>")
        sb.AppendLine("</div>")

        sb.AppendLine("<div class=""section"">")
        sb.AppendLine("<h2>Device Identity</h2>")
        sb.AppendLine("<table class=""kv"">")
        For Each r As String() In infoRows
            sb.AppendLine("<tr><td class=""k"">" & HtmlEscape(r(0)) & "</td><td class=""v"">" & HtmlEscape(r(1)) & "</td></tr>")
        Next
        sb.AppendLine("</table>")
        sb.AppendLine("</div>")

        sb.AppendLine("<div class=""section"">")
        sb.AppendLine("<h2>Health Status &amp; Temperature</h2>")

        Dim markCls As String = "mark-good"
        Dim markText As String = health
        If health = "FAILED" Then markCls = "mark-bad"
        If health <> "GOOD" AndAlso health <> "FAILED" Then markCls = "mark-warn"

        sb.AppendLine("<div class=""status-box"">")
        sb.AppendLine("<span class=""mark " & markCls & """>[" & HtmlEscape(markText) & "]</span>")
        sb.AppendLine("<span class=""label"">Overall health assessment</span>")
        sb.AppendLine("</div>")

        sb.AppendLine("<table class=""kv"">")
        sb.AppendLine("<tr><td class=""k"">Temperature</td><td class=""v"">" & HtmlEscape(tempText) & "</td></tr>")
        sb.AppendLine("<tr><td class=""k"">Error Log</td><td class=""v"">" & HtmlEscape(errText) & "</td></tr>")
        sb.AppendLine("</table>")
        sb.AppendLine("</div>")

        sb.AppendLine("<div class=""section"">")
        sb.AppendLine("<h2>S.M.A.R.T. Attributes</h2>")
        sb.AppendLine("<table class=""data"">")
        sb.AppendLine("<tr>")
        sb.AppendLine("<th>ID</th>")
        sb.AppendLine("<th>Attribute</th>")
        sb.AppendLine("<th>Value</th>")
        sb.AppendLine("<th>Worst</th>")
        sb.AppendLine("<th>Thr</th>")
        sb.AppendLine("<th>Status</th>")
        sb.AppendLine("<th>Raw</th>")
        sb.AppendLine("</tr>")
        For Each r As String() In smartRows
            Dim cls As String = "stat-ok"
            If r(5) = "WARN" Then cls = "stat-warn"
            If r(5) = "BAD" Then cls = "stat-bad"
            sb.AppendLine("<tr>")
            sb.AppendLine("<td class=""id"">" & HtmlEscape(r(0)) & "</td>")
            sb.AppendLine("<td>" & HtmlEscape(r(1)) & "</td>")
            sb.AppendLine("<td>" & HtmlEscape(r(2)) & "</td>")
            sb.AppendLine("<td>" & HtmlEscape(r(3)) & "</td>")
            sb.AppendLine("<td>" & HtmlEscape(r(4)) & "</td>")
            sb.AppendLine("<td class=""" & cls & """>" & HtmlEscape(r(5)) & "</td>")
            sb.AppendLine("<td>" & HtmlEscape(r(6)) & "</td>")
            sb.AppendLine("</tr>")
        Next
        sb.AppendLine("</table>")
        sb.AppendLine("</div>")

        sb.AppendLine("<div class=""section last"">")
        sb.AppendLine("<h2>Self-Test History</h2>")
        If selfTestText.Length = 0 Then
            sb.AppendLine("<div class=""pre"">No self-test history recorded.</div>")
        Else
            sb.AppendLine("<div class=""pre"">" & HtmlEscape(selfTestText) & "</div>")
        End If
        sb.AppendLine("</div>")

        sb.AppendLine("<div class=""footer"">")
        sb.AppendLine("<strong>PHD &middot; Pongo Hard Drive</strong><br>")
        sb.AppendLine("" & HtmlEscape(CreditLine()) & "<br>")
        sb.AppendLine("<a href=""https://" & HtmlEscape(CreditSite()) & """ style=""color: #0000FF;"">" & HtmlEscape(CreditSite()) & "</a>")
        sb.AppendLine("</div>")

        sb.AppendLine("</div>")
        sb.AppendLine("</div>")
        sb.AppendLine("</body>")
        sb.AppendLine("</html>")
        Return sb.ToString()
    End Function
    Private Function ExtractBrand(ByVal family As String) As String
        If family Is Nothing OrElse family.Length = 0 Then Return Nothing
        Dim known() As String = New String() {"Western Digital", "Silicon Power", "SK Hynix", _
            "Team Group", "Seagate", "Toshiba", "Samsung", "Hitachi", "HGST", "Maxtor", _
            "Fujitsu", "Intel", "Kingston", "Crucial", "SanDisk", "Micron", "Kioxia", _
            "ADATA", "Transcend", "Apple", "OCZ", "Plextor", "Corsair", "PNY", "Verbatim", _
            "Patriot", "Lexar", "Lenovo", "Dell", "HP", "IBM"}
        For Each b As String In known
            If family.ToLower().StartsWith(b.ToLower()) Then Return b
        Next
        Dim sp As Integer = family.IndexOf(" "c)
        If sp > 0 Then Return family.Substring(0, sp)
        Return family
    End Function

    Private Function AttrStatus(ByVal id As Integer, ByVal name As String, ByVal value As Integer, _
                                 ByVal thresh As Integer, ByVal whenFailed As String, ByVal raw As String) As String
        If whenFailed IsNot Nothing AndAlso whenFailed <> "-" AndAlso whenFailed.Length > 0 Then
            Return "BAD"
        End If

        Dim lowName As String = name.ToLower()

        If lowName = "temperature celsius" OrElse lowName = "airflow temperature cel" Then
            Dim t As Integer = 0
            Integer.TryParse(FirstToken(raw), t)
            If t >= 55 Then Return "BAD"
            If t >= 45 Then Return "WARN"
        End If

        If id = 5 OrElse id = 197 OrElse id = 198 Then
            If value < 100 Then Return "WARN"
        End If
        If id = 199 Then
            If value < 200 Then Return "WARN"
        End If
        If id = 187 Then
            If value < 100 Then Return "WARN"
        End If

        If thresh > 0 AndAlso value <= thresh Then Return "BAD"
        If thresh > 0 AndAlso value <= thresh + 10 Then Return "WARN"

        Return "OK"
    End Function

    Private Function StatusBadge(ByVal status As String) As String
        Select Case status
            Case "OK" : Return "[OK]"
            Case "WARN" : Return "[!!]"
            Case "BAD" : Return "[XX]"
            Case Else : Return "[--]"
        End Select
    End Function

    Private Function StatusColor(ByVal status As String) As ConsoleColor
        Select Case status
            Case "OK" : Return ConsoleColor.Gray
            Case "WARN" : Return ConsoleColor.DarkYellow
            Case "BAD" : Return ConsoleColor.DarkRed
            Case Else : Return ConsoleColor.DarkGray
        End Select
    End Function

    Private Function FormatRawValue(ByVal name As String, ByVal raw As String) As String
        If raw Is Nothing OrElse raw.Length = 0 Then Return "-"

        Dim firstTok As String = FirstToken(raw)
        Dim num As Long = 0
        Dim isNum As Boolean = Long.TryParse(firstTok, num)

        Dim lowName As String = name.ToLower()

        If lowName.IndexOf("temperature") >= 0 AndAlso isNum Then
            Return firstTok & "C"
        End If

        If (lowName = "power on hours" OrElse lowName = "head flying hours") AndAlso isNum Then
            Return firstTok & "h"
        End If

        If isNum Then
            If num >= 1000000 Then Return (num \ 1000000).ToString() & "M"
            If num >= 1000 Then Return (num \ 1000).ToString() & "K"
            Return num.ToString()
        End If
        Return firstTok
    End Function

    Private Sub ShowErrorLog(ByVal raw As String)
        Console.WriteLine()
        SectionTop("ERROR LOG", ConsoleColor.Gray)

        Dim errCount As String = Nothing
        Dim noErrors As Boolean = False
        Dim hasLog As Boolean = False

        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.StartsWith("ATA Error Count:") Then
                errCount = t.Substring("ATA Error Count:".Length).Trim()
            End If
            If t.StartsWith("SMART Error Log Version:") Then
                hasLog = True
            End If
            If hasLog AndAlso t.StartsWith("No Errors Logged") Then
                noErrors = True
            End If
        Next

        If errCount IsNot Nothing Then
            SectionLine("  Recorded errors  :  " & errCount, ConsoleColor.Gray)
        End If

        If noErrors Then
            SectionLine("  [OK]  No errors have been recorded.", ConsoleColor.Gray)
        ElseIf errCount Is Nothing AndAlso Not hasLog Then
            SectionLine("  This device does not provide an error log.", ConsoleColor.DarkGray)
        ElseIf errCount IsNot Nothing Then
            SectionLine("  [!!]  Errors recorded. Review details if needed.", ConsoleColor.DarkYellow)
        End If

        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Sub ShowSelfTestLog(ByVal raw As String)
        Console.WriteLine()
        SectionTop("SELF-TEST HISTORY", ConsoleColor.Gray)

        Dim collecting As Boolean = False
        Dim found As Boolean = False
        Dim count As Integer = 0

        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            If t.StartsWith("Num  Test_Description") Then
                collecting = True
                Continue For
            End If

            If collecting Then
                If t.Length = 0 Then
                    collecting = False
                    Continue For
                End If
                If Not t.StartsWith("#") Then
                    collecting = False
                    Continue For
                End If
                If count >= 5 Then Continue For

                found = True
                count += 1
                SectionLine("  " & t, ConsoleColor.Gray)
            End If
        Next

        If Not found Then
            SectionLine("  No self-test history recorded.", ConsoleColor.DarkGray)
        End If

        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Function ResolveDevice(ByVal arg As String) As String
        If arg Is Nothing OrElse arg.Length = 0 Then
            If _devices.Count = 1 Then Return _devices(0)
            If _devices.Count = 0 Then
                Throw New Exception("No devices are available. Run 'scan' first.")
            End If
            Throw New Exception("Please specify a device ID. Example: info 0")
        End If

        Dim n As Integer
        If Integer.TryParse(arg, n) Then
            If _devices.Count = 0 Then
                Throw New Exception("No devices are available. Run 'scan' first.")
            End If
            If n < 0 OrElse n >= _devices.Count Then
                Throw New Exception("The device ID " & n & " is not valid. Run 'scan' to list available devices.")
            End If
            Return _devices(n)
        End If

        Return arg
    End Function

    Private Function GetFullData(ByVal dev As String) As String
        If _cachedDev = dev AndAlso _cachedData IsNot Nothing Then
            Return _cachedData
        End If
        _cachedData = InvokeSmartctl("--all " & GetDeviceArgs(dev))
        _cachedDev = dev
        Return _cachedData
    End Function

    Private Function InvokeSmartctl(ByVal arguments As String) As String
        If _smartctlPath Is Nothing Then Return ""

        Dim psi As New ProcessStartInfo()
        psi.FileName = _smartctlPath
        psi.Arguments = arguments
        psi.UseShellExecute = False
        psi.RedirectStandardOutput = True
        psi.RedirectStandardError = True
        psi.CreateNoWindow = True

        Dim proc As Process = Process.Start(psi)
        Dim sb As New StringBuilder()
        Try
            sb.Append(proc.StandardOutput.ReadToEnd())
            proc.StandardError.ReadToEnd()
            proc.WaitForExit()
        Finally
            proc.Close()
        End Try
        Return sb.ToString()
    End Function

    Private Function GetLines(ByVal raw As String) As String()
        If raw Is Nothing Then Return New String() {}
        Dim norm As String = raw.Replace(vbCrLf, vbLf).Replace(vbCr, vbLf)
        Return norm.Split(New Char() {ChrW(10)}, StringSplitOptions.RemoveEmptyEntries)
    End Function

    Private Function FindField(ByVal raw As String, ByVal keys As String()) As String
        For Each ln As String In GetLines(raw)
            Dim t As String = ln.Trim()
            Dim idx As Integer = t.IndexOf(":"c)
            If idx <= 0 Then Continue For
            Dim key As String = t.Substring(0, idx).Trim()
            For Each k As String In keys
                If String.Compare(key, k, True) = 0 Then
                    Return t.Substring(idx + 1).Trim()
                End If
            Next
        Next
        Return Nothing
    End Function

    Private Function CenterText(ByVal text As String, ByVal width As Integer) As String
        If text.Length >= width Then Return text.Substring(0, width)
        Dim left As Integer = (width - text.Length) \ 2
        Dim right As Integer = width - text.Length - left
        Return New String(" "c, left) & text & New String(" "c, right)
    End Function

    Private Sub PrintHeader()
        Console.Clear()
        Console.ForegroundColor = ConsoleColor.Gray
        Console.WriteLine("  +" & New String("-"c, INNER_W) & "+")
        Console.WriteLine("  |" & New String(" "c, INNER_W) & "|")
        Console.ForegroundColor = ConsoleColor.White
        Console.WriteLine("  |" & CenterText("(Pongo Hard Drive)", INNER_W) & "|")
        Console.ForegroundColor = ConsoleColor.Gray
        Console.WriteLine("  |" & CenterText("Free HDD/SSD Diagnostic Tools", INNER_W) & "|")
        Console.WriteLine("  |" & New String(" "c, INNER_W) & "|")
        Console.ForegroundColor = ConsoleColor.DarkGray
        Console.WriteLine("  |" & CenterText("(c) 2015 - " & DateTime.Now.Year.ToString() & "  Ari Sohandri Putra. All Rights Reserved", INNER_W) & "|")
        Console.WriteLine("  |" & CenterText("www.pongo.my.id", INNER_W) & "|")
        Console.ForegroundColor = ConsoleColor.Gray
        Console.WriteLine("  |" & New String(" "c, INNER_W) & "|")
        Console.WriteLine("  +" & New String("-"c, INNER_W) & "+")
        Console.ResetColor()
    End Sub

    Private Sub PrintAbout()
        Console.WriteLine()
        SectionTop("ABOUT", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   PHD - Pongo Hard Drive", ConsoleColor.White)
        SectionLine("   Free HDD/SSD Diagnostic Tools", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   " & CreditLine(), ConsoleColor.DarkGray)
        SectionLine("   " & CreditSite(), ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("   Distributed for diagnostic and personal use.", ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Sub PrintHelp()
        Console.WriteLine()
        SectionTop("COMMAND REFERENCE", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("  scan                       -  Scan all storage devices", ConsoleColor.Gray)
        SectionLine("  info    <ID>               -  Show device identity", ConsoleColor.Gray)
        SectionLine("  status  <ID>               -  Show health status", ConsoleColor.Gray)
        SectionLine("  temp    <ID>               -  Show temperature report", ConsoleColor.Gray)
        SectionLine("  detail  <ID>               -  Show S.M.A.R.T. attribute table", ConsoleColor.Gray)
        SectionLine("  all     <ID>               -  Show everything above", ConsoleColor.Gray)
        SectionLine("  probe   <ID> <action>      -  Run diagnostic probe", ConsoleColor.Gray)
        SectionLine("                                actions: quick | deep", ConsoleColor.DarkGray)
        SectionLine("                                         report | stop", ConsoleColor.DarkGray)
        SectionLine("  export  <ID> <fmt> [path]  -  Export device report", ConsoleColor.Gray)
        SectionLine("                                formats: txt | json | html", ConsoleColor.DarkGray)
        SectionLine("  submit  <ID>               -  Publish report to pongo.my.id", ConsoleColor.Gray)
        SectionLine("  about                      -  Show program credits", ConsoleColor.Gray)
        SectionLine("  clear                      -  Clear the screen", ConsoleColor.Gray)
        SectionLine("  exit                       -  Quit the program", ConsoleColor.Gray)
        SectionLine("", ConsoleColor.Gray)
        SectionLine("  Examples:", ConsoleColor.DarkGray)
        SectionLine("    scan", ConsoleColor.DarkGray)
        SectionLine("    all 0", ConsoleColor.DarkGray)
        SectionLine("    export 0 html C:\Reports", ConsoleColor.DarkGray)
        SectionLine("    submit 0", ConsoleColor.DarkGray)
        SectionLine("", ConsoleColor.Gray)
        SectionBottom(ConsoleColor.Gray)
    End Sub

    Private Sub SectionTop(ByVal title As String, ByVal col As ConsoleColor)
        Dim head As String = "- " & title & " "
        Dim remain As Integer = INNER_W - head.Length
        If remain < 0 Then remain = 0
        Console.ForegroundColor = col
        Console.WriteLine("  +" & head & New String("-"c, remain) & "+")
        Console.ResetColor()
    End Sub

    Private Sub SectionBottom(ByVal col As ConsoleColor)
        Console.ForegroundColor = col
        Console.WriteLine("  +" & New String("-"c, INNER_W) & "+")
        Console.ResetColor()
    End Sub

    Private Sub SectionLine(ByVal text As String, ByVal col As ConsoleColor)
        Console.ForegroundColor = col
        Console.WriteLine("  " & text)
        Console.ResetColor()
    End Sub

    Private Sub PrintFieldLine(ByVal label As String, ByVal value As String)
        If value Is Nothing OrElse value.Length = 0 Then value = "-"
        Dim line As String = "  " & label.PadRight(14) & "  :  " & value
        SectionLine(line, ConsoleColor.Gray)
    End Sub

    Private Sub PrintError(ByVal msg As String)
        Console.WriteLine()
        Console.ForegroundColor = ConsoleColor.DarkRed
        Console.WriteLine("  [X]  " & msg)
        Console.ResetColor()
    End Sub

End Module