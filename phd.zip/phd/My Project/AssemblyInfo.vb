﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Pongo Hard Drive")> 
<Assembly: AssemblyDescription("Free HDD/SSD Diagnostic Tools")> 
<Assembly: AssemblyCompany("Ari Sohandri Putra")> 
<Assembly: AssemblyProduct("Pongo Hard Drive")> 
<Assembly: AssemblyCopyright("© 2015 - 2026 Ari Sohandri Putra. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("646e4221-4fc1-432b-aaa2-00e5e3019be5")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
